# Amazon - Tower , (Toggle Tab = Warriors Dwelling)
# Atlantean - Tower
# Barbarian - 
# Empire -
# Frisian - 
#key = # =


#
#

import widelands
widelands.call_shortcut('equal',keyboard)







