# Amazon - Tower , (Toggle Tab = Warriors Dwelling)
# Atlantean - Tower
# Barbarian - 
# Empire -
# Frisian - 
#key = # =


#
#

import widelands.core
widelands.core.call_shortcut('equal',keyboard)







