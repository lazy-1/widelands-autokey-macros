# Amazon - Patrol-Post
# Atlantean - Guardhouse
# Barbarian - 
# Empire -
# Frisian - 
#key = # -


#
#

import widelands
widelands.call_shortcut('hyphen',keyboard)







