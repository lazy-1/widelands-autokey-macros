# Amazon - Patrol-Post
# Atlantean - Guardhouse
# Barbarian - 
# Empire -
# Frisian - 
#key = # -


#
#

import widelands.core
widelands.core.call_shortcut('hyphen',keyboard)







