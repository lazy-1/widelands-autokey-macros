# Amazon - Woodcutter
# Atlantean - Woodcutter
# Barbarian - 
# Empire -
# Frisian - 
#key = # F2

#
#

import widelands.core
widelands.core.call_shortcut('F2',keyboard)







