# Amazon - DressMakery
# Atlantean - Weaponsmith
# Barbarian - 
# Empire -
# Frisian - 
#key = # F9

#
#

import widelands.core
widelands.core.call_shortcut('F9',keyboard)







