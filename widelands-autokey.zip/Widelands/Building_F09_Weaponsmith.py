# Amazon - DressMakery
# Atlantean - Weaponsmith
# Barbarian - 
# Empire -
# Frisian - 
#key = # F9

#
#

import widelands
widelands.call_shortcut('F9',keyboard)







