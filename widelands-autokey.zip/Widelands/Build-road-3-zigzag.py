#key = #key = # /

# Single road, no flags, 2 spaces.
# for joining paralell roads zigzag

import widelands

widelands.Build_Zigzag_Road(keyboard)

