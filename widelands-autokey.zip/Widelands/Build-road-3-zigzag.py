#key = #key = # /

# Single road, no flags, 2 spaces.
# for joining paralell roads zigzag

import widelands.common

widelands.common.Build_Zigzag_Road(keyboard)

