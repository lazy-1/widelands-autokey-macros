# Amazon - Destroy Building
# Atlantean - Destroy Building
# Barbarian - 
# Empire -
# Frisian - 
#key = # ]

# Dismantle 


import widelands.core
widelands.core.call_shortcut('scroll_lock',keyboard)






