# For Development, used to reload module after edit.
#key = # `

# AutoKey dev script: Reload widelands package + re-apply tribe loading

import importlib
import sys

PACKAGE = 'widelands'

# Step 1: Force-reload the whole package by removing from sys.modules
# (this makes Python re-execute __init__.py, core.py, etc. on next import)
if PACKAGE in sys.modules:
    del sys.modules[PACKAGE]
    print(f"Removed {PACKAGE} from sys.modules")

# Also remove known submodules to be extra sure
for mod_name in list(sys.modules.keys()):
    if mod_name.startswith(PACKAGE + '.'):
        del sys.modules[mod_name]

print(f"Cleared {PACKAGE} and all submodules from sys.modules")

# Step 2: Re-import the package → runs core.py top-level code again
# (including get_tribe() + __import__ tribe file + globals().update)
try:
    widelands = importlib.import_module(PACKAGE)
    print(f"Successfully re-imported {PACKAGE}")
except Exception as e:
    print(f"Failed to re-import {PACKAGE}: {e}")
    raise

# Optional quick smoke test
from widelands.core import CONTEXT
print("Current tribe after reload:", CONTEXT.get('tribe'))
# You can add: print("F1 function:", widelands.core.F1 if hasattr(widelands.core, 'F1') else "not found")

widelands.common._play_sound('meedmeep')
print("Reset transient_store variables to False")


