#key = # '

# Connecting Roads with flags.

import widelands.common

widelands.common.Build_Connect_Road(keyboard)


















