#key = # '

# Connecting Roads with flags.

import widelands

widelands.Build_Connect_Road(keyboard)


















