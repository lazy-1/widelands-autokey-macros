# Amazon - Chocolate_Brewery
# Atlantean - Smokery
# Barbarian - 
# Empire -
# Frisian - 
#key = # F6

#
#

import widelands.core
widelands.core.call_shortcut('F6',keyboard)







