# Amazon - Dismantle Stonecutter (upgrade woodcutter)
# Atlantean - Dismantle Stonecutter
# Barbarian - 
# Empire -
# Frisian - 
#key = # ]

# Dismantle 


import widelands.core
widelands.core.call_shortcut('rightbracket',keyboard)






