# Amazon -  Upgrade Woodcutter, Tower, Fortress
# Atlantean -  Upgrade Tower
# Barbarian - 
# Empire -
# Frisian - 
#key = # [

# Double Click. (Delete road under mouse, clean up foresters)

import widelands.core
widelands.core.call_shortcut('leftbracket',keyboard)

