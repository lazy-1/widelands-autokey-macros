# Amazon - Double Click Mouse
# Atlantean - Double Click Mouse
# Barbarian - 
# Empire -
# Frisian - 
#key = # ]

# Dismantle 


import widelands.core
widelands.core.call_shortcut('rightbracket',keyboard)






