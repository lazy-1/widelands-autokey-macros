# Amazon - Jungle_Preserve
# Atlantean - Forester
# Barbarian - 
# Empire -
# Frisian - 
#key = # F3

#
#

import widelands
widelands.call_shortcut('F3',keyboard)







