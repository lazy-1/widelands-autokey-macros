# Amazon - Jungle_Preserve
# Atlantean - Forester
# Barbarian - 
# Empire -
# Frisian - 
#key = # F3

#
#

import widelands.core
widelands.core.call_shortcut('F3',keyboard)







