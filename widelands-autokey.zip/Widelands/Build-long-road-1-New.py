#key = # ;

# New Road, with Flags

import widelands.common

widelands.common.Build_New_Road(keyboard)




