#key = # ;

# New Road, with Flags

import widelands

widelands.Build_New_Road(keyboard)




