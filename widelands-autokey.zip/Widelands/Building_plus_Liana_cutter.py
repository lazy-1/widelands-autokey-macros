# Amazon - Liana_Cutter toggle_tab Rope_Weaver
# Atlantean - 
# Barbarian - 
# Empire -
# Frisian - 
#key = # end


#
#

import widelands.core
widelands.core.call_shortcut('plus',keyboard)

