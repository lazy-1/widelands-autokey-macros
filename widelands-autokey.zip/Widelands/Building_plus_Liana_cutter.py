# Amazon - Liana_Cutter
# Atlantean - 
# Barbarian - 
# Empire -
# Frisian - 
#key = # end


#
#

import widelands
widelands.call_shortcut('plus',keyboard)

