# Amazon - Liana_Cutter
# Atlantean - 
# Barbarian - 
# Empire -
# Frisian - 
#key = # end


#
#

import widelands.core
widelands.core.call_shortcut('plus',keyboard)

