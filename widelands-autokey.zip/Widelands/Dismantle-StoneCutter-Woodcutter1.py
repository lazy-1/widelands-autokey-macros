# Amazon - Dismantle Stonecutter (upgrade woodcutter)
# Atlantean - Dismantle Stonecutter
# Barbarian - 
# Empire -
# Frisian - 
#key = # ]

# Dismantle 


import widelands
widelands.call_shortcut('scroll_lock',keyboard)






