# Amazon - Stone_Workshop
# Atlantean - SawMill
# Barbarian - 
# Empire -
# Frisian - 
#key = # end


#
#

import widelands.core
widelands.core.call_shortcut('end',keyboard)







