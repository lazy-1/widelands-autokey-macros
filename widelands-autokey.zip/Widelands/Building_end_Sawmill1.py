# Amazon - Stone_Workshop
# Atlantean - SawMill
# Barbarian - 
# Empire -
# Frisian - 
#key = # end


#
#

import widelands
widelands.call_shortcut('end',keyboard)







