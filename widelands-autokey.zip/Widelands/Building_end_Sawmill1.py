# Amazon - Stone_Workshop toggle_tab Furnace
# Atlantean - SawMill
# Barbarian - 
# Empire -
# Frisian - 
#key = # end


#
#

import widelands.core
widelands.core.call_shortcut('end',keyboard)







