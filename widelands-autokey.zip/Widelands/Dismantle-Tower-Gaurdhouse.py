# Amazon - Dismantle Patrol-Post
# Atlantean - Dismantle Gaurdhouse, Tower and Castle
# Barbarian - 
# Empire -
# Frisian - 
#key = # \

# Dismantle 


import widelands
widelands.call_shortcut('backslash',keyboard)



