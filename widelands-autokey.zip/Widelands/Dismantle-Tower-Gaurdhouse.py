# Amazon - Dismantle Patrol-Post
# Atlantean - Dismantle Gaurdhouse, Tower and Castle
# Barbarian - 
# Empire -
# Frisian - 
#key = # \

# Dismantle 


import widelands.core
widelands.core.call_shortcut('backslash',keyboard)



