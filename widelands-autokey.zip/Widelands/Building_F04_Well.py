# Amazon - Water_Gatherer
# Atlantean - Well
# Barbarian - 
# Empire -
# Frisian - 
#key = # F4

#
#

import widelands.core
widelands.core.call_shortcut('F4',keyboard)







