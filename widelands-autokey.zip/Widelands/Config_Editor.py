# Enter script code

# AutoKey script – very clean
import widelands.bootstrap

widelands.bootstrap.launch_editor()

engine.run_script("00-Reload_module")