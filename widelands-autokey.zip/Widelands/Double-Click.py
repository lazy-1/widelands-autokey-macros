#key = # [

# Double Click. (Delete road under mouse, clean up foresters)

import widelands
widelands.call_shortcut('leftbracket',keyboard)

