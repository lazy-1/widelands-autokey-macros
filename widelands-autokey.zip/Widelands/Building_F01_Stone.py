# Amazon - Stonecutter
# Atlantean - Quary
# Barbarian - 
# Empire -
# Frisian - 
#key = # F1

#
#

import widelands
widelands.call_shortcut('F1',keyboard)







