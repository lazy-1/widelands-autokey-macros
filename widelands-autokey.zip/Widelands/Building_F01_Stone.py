# Amazon - Stonecutter
# Atlantean - Quary
# Barbarian - 
# Empire -
# Frisian - 
#key = # F1

#
#

import widelands.core
widelands.core.call_shortcut('F1',keyboard)







