# Amazon - Hunter_Gatherer
# Atlantean - Fish
# Barbarian - 
# Empire -
# Frisian - 
#key = # F11


#
#

import widelands
widelands.call_shortcut('F11',keyboard)







