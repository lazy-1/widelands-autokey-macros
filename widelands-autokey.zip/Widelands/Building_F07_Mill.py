# Amazon - Charcoal_Kiln
# Atlantean - Mill
# Barbarian - 
# Empire -
# Frisian - 
#key = # F7
# Enter script code

#
#

import widelands.core
widelands.core.call_shortcut('F7',keyboard)







