# Amazon - Charcoal_Kiln
# Atlantean - Mill
# Barbarian - 
# Empire -
# Frisian - 
#key = # F7
# Enter script code

#
#

import widelands
widelands.call_shortcut('F7',keyboard)







