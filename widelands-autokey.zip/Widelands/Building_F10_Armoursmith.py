# Amazon - Rare_Tree_Plantation
# Atlantean - Armoursmith
# Barbarian - 
# Empire -
# Frisian - 
#key = # F10

#
#

import widelands
widelands.call_shortcut('F10',keyboard)







