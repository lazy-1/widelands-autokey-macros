# Amazon - Wilderness_Keeper
# Atlantean - Fishbreader
# Barbarian - 
# Empire -
# Frisian - 
#key = # F12


#
#

import widelands.core
widelands.core.call_shortcut('F12',keyboard)







