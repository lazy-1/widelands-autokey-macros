#key = # z


keyboard.send_keys("<pause>")