#key = # spacebar
# used for pausing the game.


keyboard.send_keys("<pause>")