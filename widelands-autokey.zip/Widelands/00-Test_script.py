# Enter script code



import widelands.core
widelands.core.simple_tst('end',keyboard)













