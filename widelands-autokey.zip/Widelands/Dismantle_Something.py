# Amazon - Dismantle 
# Atlantean - Dismantle 
# Barbarian - 
# Empire -
# Frisian - 
#key = # \

# Dismantle 


import widelands.core
widelands.core.call_shortcut('backslash',keyboard)



