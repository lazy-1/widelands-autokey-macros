# Amazon - Food_Preserver
# Atlantean - Smelter
# Barbarian - 
# Empire -
# Frisian - 
#key = # F8

#
#

import widelands
widelands.call_shortcut('F8',keyboard)







