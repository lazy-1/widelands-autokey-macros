# Amazon - Food_Preserver
# Atlantean - Smelter
# Barbarian - 
# Empire -
# Frisian - 
#key = # F8

#
#

import widelands.core
widelands.core.call_shortcut('F8',keyboard)







