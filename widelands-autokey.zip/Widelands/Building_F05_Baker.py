# Amazon - Cassava_Root_Cooker
# Atlantean - Bakery
# Barbarian - 
# Empire -
# Frisian - 
#key = # F5

#
#

import widelands.core
widelands.core.call_shortcut('F5',keyboard)







